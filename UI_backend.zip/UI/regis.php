<?php

$br_id=$_POST['br_id'];

$name=$_POST['name'];

$email_id=$_POST['email_id'];

$ph_number=$_POST['ph_number'];

$commission=$_POST['commission'];

$host = "localhost";

$user = "root";

$password = '';

$db_name = "prop";




$con = mysqli_connect($host, $user, $password, $db_name);

if(mysqli_connect_errno())

{

die("Failed to connect with MySQL: ". mysqli_connect_error());

}



$stmt=$con->prepare("insert into broker1 values('$br_id','$name','$commission')");

$stmt->execute();

$stmt1=$con->prepare("insert into broker2 values('$br_id','$ph_number')");

$stmt1->execute();

$stmt2=$con->prepare("insert into broker3 values('$br_id','$email_id')");

$stmt2->execute();

echo "success"

?>