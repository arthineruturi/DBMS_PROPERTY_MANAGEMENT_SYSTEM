<?php

$B_id=$_POST['B_id'];

$B_name=$_POST['B_name'];

$Email_id=$_POST['Email_id'];

$Ph_number=$_POST['Ph_number'];

$host = "localhost";

$user = "root";

$password = '';

$db_name = "prop";




$con = mysqli_connect($host, $user, $password, $db_name);

if(mysqli_connect_errno())

{

die("Failed to connect with MySQL: ". mysqli_connect_error());

}
$stmt=$con->prepare("insert into buyer1 values('$B_id','$B_name')");

$stmt->execute();
$stmt2=$con->prepare("insert into buyer3 values('$B_id','$Email_id')");

$stmt2->execute();

$stmt1=$con->prepare("insert into buyer2 values('$B_id','$Ph_number')");
$stmt1->execute();



echo "REGISTRATION IS SUCCESSFUL !!! YOU CAN GO BACK TO LOGIN"

?>