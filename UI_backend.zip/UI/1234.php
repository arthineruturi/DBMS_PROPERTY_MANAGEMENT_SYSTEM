<?php

  $s_id=$_POST['s_id'];
 $name=$_POST['name'];
$Email_id=$_POST['Email_id'];
$Phone_no=$_POST['Phone_number'];
$conn=mysqli_connect("localhost","root","","prop");
if($conn -> connect_error)
  {
     die("Connection failed:".$conn -> connect_error);
  }else{
  
      
    $stmt=$conn -> prepare("insert into seller1 values('$s_id','$name')");
    $stmt=$conn -> prepare("insert into seller3 values('$s_id','$Email_id')");
    $stmt=$conn -> prepare("insert into seller2 values('$s_id','$Phone_no')");
     $stmt->execute(); 
    $stmt->close(); 
     $conn->close();
     echo "Success! Database Updated";
    }
   
?>

<html><head>
    <link rel="stylesheet" href="11.css">
</head>
<body>
    <img src="123.jfif"></img>
        <div class="wrapper">
           

            <form action="1234.php" class="form" method="post">

                <h2>REGISTRATION FORM</h2>
                <div class="inputdiv">
                    <input type="text" name="s_id" id="s_id" required>
                    <label for="userlogin">s_id</label>
                </div>
                
                <div class="inputdiv">
                    <input type="text" name="name" id="name" required>
                    <label for="userlogin">Name</label>
                </div>
                <div class="inputdiv">
                    <input type="text" name="Phone_no" id="phone_no" required>
                    <label for="userlogin">phone_no</label>
                </div>
                
                <div class="inputdiv">
                    <input type="text" name="Email_id" id="Email_id" required>
                    <label for="userlogin">Email_id</label>
                </div>
              
                
               
                <input type="submit" value="submit" class="submitbtn">
            </form>
        
        </div>
    </body></html>