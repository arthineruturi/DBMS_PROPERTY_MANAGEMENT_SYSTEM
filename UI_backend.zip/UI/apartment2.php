<html>
    <style>
           @import "css.css";
        @import url("css.css");
        table {
  border-collapse: collapse;
  width: 45%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: teal;
  color: white;
}
.mySlides {display:none}
.w3-left, .w3-right, .w3-badge {cursor:pointer}
.w3-badge {height:13px;width:13px;padding:0}
    </style>
     <div id="navbar">
            
        <a href="Apartment.html">&nbsp;APARTMENTS</a>
         </div>
         <!-- Container for the image gallery -->
<div class="container">
<center>
<!-- Full-width images with number text -->
<div class="mySlides">
    <div class="numbertext">1 / 4</div>
      <img src="https://kg-constructions.com/wp-content/uploads/2020/01/al-aqsa-1.jpeg" style="width:100% " height="500px">
  </div>

  <div class="mySlides">
    <div class="numbertext">2 / 4</div>
      <img src="1_b.jpg" style="width:100% " height="500px">
  </div>

  <div class="mySlides">
    <div class="numbertext">3 / 4</div>
      <img src="1_c.jpg" style="width:100% " height="500px">
  </div>

  <div class="mySlides">
    <div class="numbertext">4 / </div>
      <img src="2_a.jpg" style="width:100% " height="500px">
  </div>
<!-- Next and previous buttons -->
<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

<!-- Image text -->
<div class="caption-container">
  <p id="caption"></p>
</div>

<!-- Thumbnail images -->
<div class="row">
  <div class="column">
    <img class="demo cursor"src="https://kg-constructions.com/wp-content/uploads/2020/01/al-aqsa-1.jpeg" style="width:100%; height: 150px" onclick="currentSlide(1)" alt="Photo 1">
  </div>
  <div class="column">
    <img class="demo cursor" src="1_b.jpg" style="width:100%" onclick="currentSlide(2)" alt="Photo 2">
  </div>
  <div class="column">
    <img class="demo cursor" src="1_c.jpg" style="width:100%" onclick="currentSlide(3)" alt="Photo 3">
  </div>
  <div class="column">
    <img class="demo cursor" src="2_a.jpg" style="width:100%;height: 150px;" onclick="currentSlide(4)" alt="Photo 4">
  </div>
  <div class="column">
    
  </div>
</div>
</div>
<div class="w3-content w3-display-container">
</center>

            <div class="w3-center w3-display-bottommiddle" style="width:100%">
            <center><center>
            <font color="red">
            SELLER DETAILS:
          </font>
        </center>
        <table border="1" style="height: 70px;">



          <tr>
          <th>S_ID </th>
          
          
          
          <th>NAME </th>
          <th>PH_NUMBER </th>
          <th>EMAIL </th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
          
          $sql = "SELECT * FROM seller1 where s_id = 's05'";
          $sql1 = "SELECT ph_number FROM seller2 where s_id = 's05'";
          $sql2 = "SELECT email FROM seller3 where s_id = 's05'";
          
          $result=mysqli_query($con,$sql);
          $result1=mysqli_query($con,$sql1);
          $num=mysqli_num_rows($result);
          $num1=mysqli_num_rows($result1);
          $result2=mysqli_query($con,$sql2);
          $num2=mysqli_num_rows($result2);
          if($num>0 )
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["s_id"]."</td><td>".$data["name"]."</td>";
          
          
          }
          while($data = $result1->fetch_assoc()){
            echo "<td>".$data["ph_number"]."</td>";
        
        
        }
        while($data = $result2->fetch_assoc()){
          echo "<td>".$data["email"]."</td>";
      
      
      }
         
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>
         </p>  
         <center><br>
          <font color="red">
          PROPERTY DETAILS:
          </font>
        </center>
        <table border="1" style="height: 70px;">



          <tr>
          <th>PROPERTY_ID </th>
                   
          
          <th>S_ID </th>
          
          <th>NAME</th>
          <th>LOCATION</th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
                 
          $sql = "SELECT Property_id,s_id,name,location FROM Property where Property_id = 'pr05'";
          $result=mysqli_query($con,$sql);
          $num=mysqli_num_rows($result);
          if($num>0)
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["Property_id"]."</td><td>".$data["s_id"]."</td><td>".$data["name"]."</td><td>".$data["location"]."</td>";
          
          }
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>
          <center><br>
          <font color="red">
            ADMIN DETAILS:
          </font>
        </center>

        <table border="1" style="height: 70px;">

        <tr>
          <th>A_ID </th>
          
          
          
          <th>NAME </th>
          <th>PH_NUMBER </th>
          <th>EMAIL </th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
          
          $sql = "SELECT * FROM admin1 where A_id = 'A05'";
          $sql1 = "SELECT ph_number FROM admin2 where A_id = 'A05'";
          $sql2 = "SELECT email_ID FROM admin3 where A_id = 'A05'";
          
          $result=mysqli_query($con,$sql);
          $result1=mysqli_query($con,$sql1);
          $num=mysqli_num_rows($result);
          $num1=mysqli_num_rows($result1);
          $result2=mysqli_query($con,$sql2);
          $num2=mysqli_num_rows($result2);
          if($num>0 )
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["A_id"]."</td><td>".$data["A_name"]."</td>";
          
          
          }
          while($data = $result1->fetch_assoc()){
            echo "<td>".$data["ph_number"]."</td>";
        
        
        }
        while($data = $result2->fetch_assoc()){
          echo "<td>".$data["email_ID"]."</td>";
      
      
      }
         
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>                
            
              
            </center>
            </center>
              </div>
             
        </body>
          
          </div>
    </body>
    <script src="js.js"></script>
</html>