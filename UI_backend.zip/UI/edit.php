<?php
    include 'connect.php';

            $id = $_POST['A_id'];
            $sql="select A_name from admin1 where A_id = '$id'";
            $sql1="select Ph_number from admin2 where A_id = '$id'";
            $sql2="select Email_id from admin3 where A_id = '$id'";
            $result = mysqli_query($con,$sql);
            $result1 = mysqli_query($con,$sql1);
            $result2 = mysqli_query($con,$sql2);
            
            $num = mysqli_num_rows($result);
           
            if($num==1)
		    { 
                
                $new_name=$_POST['A_name'];
           
                $new_phno=$_POST['Ph_number'];

                 $new_email=$_POST['Email_id'];
                //session_start(); 
                $sql3="update admin1 set A_name ='$new_name' where A_id='$id'";
                $result3=mysqli_query($con,$sql3); 

                $sql4="update admin2 set Ph_number ='$new_phno' where A_id = '$id'";
                $result4=mysqli_query($con,$sql4);

                $sql5="update admin3 set Email_id ='$new_email' where A_id='$id'";
                $result=mysqli_query($con,$sql5);

                echo '<script>alert("Details Changes are done")</script>';
                echo "  <script>
                window.location = 'prac.php'
                  </script> ";                 //CHANGE TO prac.php-->ADMIN
		     }


        else{
          echo '<script>alert("Invalid ID")</script>';
          
           echo "  <script>
          window.location = 'prac.php'
          </script> ";
       }
?>

