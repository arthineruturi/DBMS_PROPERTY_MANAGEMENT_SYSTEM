<!DOCTYPE html>
<html lang="en">



<head>
<meta charset="UTF-8">



<meta http-equiv="X-UA-Compatible" content="IE=edge">



<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<table>



<tr>
<th>S_ID </th>



<th>NAME </th>

<?php
$host = "localhost";
$user = "root";
$password = '';
$db_name = "propmania";

$con = mysqli_connect($host, $user, $password, $db_name);
if(mysqli_connect_errno())
{
die("Failed to connect with MySQL: ". mysqli_connect_error());
}

$sql = "SELECT s_id,name FROM seller1 where s_id = 's01'";

$result=mysqli_query($con,$sql);
$num=mysqli_num_rows($result);
if($num>0)
{
while($data = $result->fetch_assoc()){
    echo "<tr><td>".$data["s_id"]."</td><td>".$data["name"]."</td>";

}
echo "</table>";
}

?>
</tr>
</table>
</body>



</html>



</body>



</html>