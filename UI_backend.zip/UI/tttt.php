<?php
$s_id=$_POST['s_id'];
$name=$_POST['name'];
$email=$_POST['email'];
$ph_number=$_POST['ph_number'];
$p_id=$_POST['p_id'];
$na=$_POST['na'];
$loc=$_POST['loc'];
$host = "localhost";
$user = "root";
$password = '';
$db_name = "prop";

$con = mysqli_connect($host, $user, $password, $db_name);
if(mysqli_connect_errno())
{
die("Failed to connect with MySQL: ". mysqli_connect_error());
}

$stmt=$con->prepare("insert into seller1 values('$s_id','$name')");
$stmt->execute();
$stmt1=$con->prepare("insert into seller3 values('$s_id','$email')");
$stmt1->execute();
$stmt2=$con->prepare("insert into seller2 values('$s_id','$ph_number')");
$stmt2->execute();
$stmt2=$con->prepare("insert into property values('$property_id','$s_id','b01','$na','$loc')");
$stmt2->execute();
header("Location: http://localhost/xampp/UI/i3.html"); 


?>