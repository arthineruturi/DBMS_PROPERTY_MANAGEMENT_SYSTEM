<!DOCTYPE html>
<html>
<head>
<style>
    @import "css.css";
        @import url("css.css");
        table {
  border-collapse: collapse;
  width: 45%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: teal;
  color: white;
}
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
 
  width: 200px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>
<body>
  
    <center>
      <div class="w3-display-container" style="margin-bottom:50px">
        <img src="https://www.forestnest.in/wp-content/uploads/2021/07/FOREST-EAST-VILLA-TYPE-3-1024x730.jpg" style="width:100%" height="750px">
        <div class="w3-display-bottomleft w3-container w3-amber w3-hover-orange w3-hide-small"
         style="bottom:10%;opacity:0.7;width:70%">
        <h2><b>INDEPENDANT HOUSES</b></h2>
      </div>
      </div>
        <a href="Buyer.html"><button type="button" style="background: rgb(44, 177, 218) ; color:rgb(31, 27, 27); border: none; cursor:pointer;">Buyer Page</button></a>
      </center></td>
    <center>
        <a href="House.html"><button type="button" style="background: rgb(44, 177, 218) ; color:rgb(31, 27, 27); border: none; cursor:pointer;">House page </button></a>
      </center></td>
  <center><div class="gallery">
       
  </div>
     <div class="gallery">
    <a target="_blank" href="https://www.forestnest.in/wp-content/uploads/2021/07/masterplan.png">
      <img src="https://www.forestnest.in/wp-content/uploads/2021/07/masterplan.png" alt="Northern Lights" width="600" height="400">
    </a>
    
  </div>
  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  
  <div class="gallery">
    <a target="_blank" href="https://www.forestnest.in/wp-content/uploads/2021/07/FOREST-EAST-VILLA-TYPE-3-1024x730.jpg">
      <img src="https://www.forestnest.in/wp-content/uploads/2021/07/FOREST-EAST-VILLA-TYPE-3-1024x730.jpg" alt="Mountains" width="600" height="400">
    </a>
    
  </div>
  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <div class="gallery">
      <a target="_blank" href="https://media.designcafe.com/wp-content/uploads/2020/07/22200504/independent-house-design-with-bold-kitchen.jpg">
        <img src="https://media.designcafe.com/wp-content/uploads/2020/07/22200504/independent-house-design-with-bold-kitchen.jpg" alt="Cinque Terre" width="600" height="400">
      </a>
      
    </div>
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    <div class="gallery">
      <a target="_blank" href="https://www.optimise-home.com/wp-content/uploads/2017/09/Albany_18.jpg">
        <img src="https://www.optimise-home.com/wp-content/uploads/2017/09/Albany_18.jpg" alt="Cinque Terre" width="600" height="400">
      </a>
     
    </div></center>
    <center>
    <center>
          <font color="red">
            SELLER DETAILS:
          </font>
        </center>
        <table border="1" style="height: 70px;">



          <tr>
          <th>S_ID </th>
          
          
          
          <th>NAME </th>
          <th>PH_NUMBER </th>
          <th>EMAIL </th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
          
          $sql = "SELECT * FROM seller1 where s_id = 's06'";
          $sql1 = "SELECT ph_number FROM seller2 where s_id = 's06'";
          $sql2 = "SELECT email FROM seller3 where s_id = 's06'";
          
          $result=mysqli_query($con,$sql);
          $result1=mysqli_query($con,$sql1);
          $num=mysqli_num_rows($result);
          $num1=mysqli_num_rows($result1);
          $result2=mysqli_query($con,$sql2);
          $num2=mysqli_num_rows($result2);
          if($num>0 )
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["s_id"]."</td><td>".$data["name"]."</td>";
          
          
          }
          while($data = $result1->fetch_assoc()){
            echo "<td>".$data["ph_number"]."</td>";
        
        
        }
        while($data = $result2->fetch_assoc()){
          echo "<td>".$data["email"]."</td>";
      
      
      }
         
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>
         </p>  
         <center><br>
          <font color="red">
          PROPERTY DETAILS:
          </font>
        </center>
        <table border="1" style="height: 70px;">



          <tr>
          <th>PROPERTY_ID </th>
                   
          
          <th>S_ID </th>
          
          <th>NAME</th>
          <th>LOCATION</th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
                 
          $sql = "SELECT Property_id,s_id,name,location FROM Property where Property_id = 'pr06'";
          $result=mysqli_query($con,$sql);
          $num=mysqli_num_rows($result);
          if($num>0)
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["Property_id"]."</td><td>".$data["s_id"]."</td><td>".$data["name"]."</td><td>".$data["location"]."</td>";
          
          }
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>
          <center><br>
          <font color="red">
            ADMIN DETAILS:
          </font>
        </center>

        <table border="1" style="height: 70px;">

        <tr>
          <th>A_ID </th>
          
          
          
          <th>NAME </th>
          <th>PH_NUMBER </th>
          <th>EMAIL </th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
          
          $sql = "SELECT * FROM admin1 where A_id = 'A08'";
          $sql1 = "SELECT ph_number FROM admin2 where A_id = 'A08'";
          $sql2 = "SELECT email_ID FROM admin3 where A_id = 'A08'";
          
          $result=mysqli_query($con,$sql);
          $result1=mysqli_query($con,$sql1);
          $num=mysqli_num_rows($result);
          $num1=mysqli_num_rows($result1);
          $result2=mysqli_query($con,$sql2);
          $num2=mysqli_num_rows($result2);
          if($num>0 )
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["A_id"]."</td><td>".$data["A_name"]."</td>";
          
          
          }
          while($data = $result1->fetch_assoc()){
            echo "<td>".$data["ph_number"]."</td>";
        
        
        }
        while($data = $result2->fetch_assoc()){
          echo "<td>".$data["email_ID"]."</td>";
      
      
      }
         
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>                
    </center><br><br><br><br><br><br></p>
    </center>

</body>
</html>


