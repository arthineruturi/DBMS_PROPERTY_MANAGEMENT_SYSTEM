<?php
$s_id1=$_POST['s_id'];
$name=$_POST['name'];
$email=$_POST['email'];
$ph_number=$_POST['ph_number'];
$na=$_POST['na'];
$loc=$_POST['loc'];
$host='localhost';
$user="root";
$password="";
$db_name="prop";
$con = mysqli_connect($host, $user, $password, $db_name);
if(mysqli_connect_errno())
{
die("Failed to connect with MySQL: ". mysqli_connect_error());
}
$q="update seller1  set  name='$name' where s_id='$s_id1'";
$qu=mysqli_query($con,$q);

$q1="update seller3  set  email='$email' where s_id='$s_id1'";
$qu1=mysqli_query($con,$q1);

$q2="update seller2  set  ph_number='$ph_number' where s_id='$s_id1'";
$qu2=mysqli_query($con,$q2);
$q7="update property  set  location='$loc',name='$na' where s_id='$s_id1'";
$qu7=mysqli_query($con,$q7);

echo "updation succesfull"
?>