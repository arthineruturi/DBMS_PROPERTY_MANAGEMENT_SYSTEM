<?php
$host='localhost';
$user="root";
$password="";
$db_name="prop";
$con = mysqli_connect($host, $user, $password, $db_name);
if(mysqli_connect_errno())
{
die("Failed to connect with MySQL: ". mysqli_connect_error());
}
$s_id1=$_POST['uname'];

$selected_radio = $_POST['ty'];
if($selected_radio=='seller'){
    $sql = "SELECT s_id,name FROM seller1 where s_id = '$s_id1'";
    $result=mysqli_query($con,$sql);
    
    $num=mysqli_num_rows($result);
   
    if($num>0){
        header("Location: http://localhost/xampp/UI/projecttt.html");
    }else{
        header("Location: http://localhost/xampp/UI/ii.html"); 
    }
}else if($selected_radio=='broker'){
    $sql = "SELECT * FROM broker1 where br_id = '$s_id1'";
    $result=mysqli_query($con,$sql);
    
    $num=mysqli_num_rows($result);
   
    if($num>0){
        header("Location:  http://localhost/xampp/UI/broker.html");
    }else{
        header("Location: http://localhost/xampp/UI/ii.html"); 
    }
}else if($selected_radio=='buyer'){
    $sql = "SELECT * FROM buyer1 where b_id = '$s_id1'";
    $result=mysqli_query($con,$sql);
    
    $num=mysqli_num_rows($result);
  
    if($num>0){
        header("Location: http://localhost/xampp/UI/buyer.html");
    }else{
        header("Location: http://localhost/xampp/UI/ii.html"); 
    }
}else if($selected_radio=='admin'){
    $sql = "SELECT * FROM admin1 where a_id = '$s_id1'";
    $result=mysqli_query($con,$sql);
    
    $num=mysqli_num_rows($result);
   
    if($num>0){
        header("Location: http://localhost/xampp/UI/prac.php");
    }else{
        header("Location:http://localhost/xampp/UI/ii.html"); 
    }
}else{
    header("Location: http://localhost/xampp/UI/i2.html"); 
}




?>