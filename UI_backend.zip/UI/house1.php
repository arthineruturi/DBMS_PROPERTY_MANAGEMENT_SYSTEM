<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
  table {
  border-collapse: collapse;
  width: 45%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: teal;
  color: white;
}
    @import "css.css";
        @import url("css.css");
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
 
  width: 200px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>
<body>
  
  <center>
    <div class="w3-display-container" style="margin-bottom:50px">
      <img src="https://freedesignfile.com/upload/2018/02/An-independent-house-with-beautiful-garden-Stock-Photo-01.jpg" style="width:100%" height="750px">
      <div class="w3-display-bottomleft w3-container w3-amber w3-hover-orange w3-hide-small"
       style="bottom:10%;opacity:0.7;width:70%">
      <h2><b>INDEPENDANT HOUSES</b></h2>
    </div>
    </div>
    <a href="Buyer.html"><button type="button" style="background: rgb(44, 177, 218) ; color:rgb(31, 27, 27); border: none; cursor:pointer;">Buyer Page</button></a>
  </center></td><br>
<center>
    <a href="House.html"><button type="button" style="background: rgb(44, 177, 218) ; color:rgb(31, 27, 27); border: none; cursor:pointer;">House page </button></a>
  </center></td><br>

<br><br>
  <center><div class="gallery">
    <a target="_blank" href="https://freedesignfile.com/upload/2018/02/An-independent-house-with-beautiful-garden-Stock-Photo-01.jpg">
      <img src="https://freedesignfile.com/upload/2018/02/An-independent-house-with-beautiful-garden-Stock-Photo-01.jpg" alt="Forest" width="600" height="400">
    </a>
   
  </div>
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <div class="gallery">
    <a target="_blank" href="https://media.designcafe.com/wp-content/uploads/2020/07/22202124/independent-house-interior-design-with-living-room.jpg">
      <img src="https://media.designcafe.com/wp-content/uploads/2020/07/22202124/independent-house-interior-design-with-living-room.jpg" alt="Northern Lights" width="600" height="400">
    </a>
    
  </div>
  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  
  <div class="gallery">
    <a target="_blank" href="https://i.ytimg.com/vi/5MdnXpMPI9I/mqdefault.jpg">
      <img src="https://i.ytimg.com/vi/5MdnXpMPI9I/mqdefault.jpg" alt="Mountains" width="600" height="400">
    </a>
    
  </div>
  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <div class="gallery">
      <a target="_blank" href="https://media.designcafe.com/wp-content/uploads/2020/07/22200504/independent-house-design-with-bold-kitchen.jpg">
        <img src="https://media.designcafe.com/wp-content/uploads/2020/07/22200504/independent-house-design-with-bold-kitchen.jpg" alt="Cinque Terre" width="600" height="400">
      </a>
      
    </div>
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    <div class="gallery">
      <a target="_blank" href="https://media.designcafe.com/wp-content/uploads/2020/07/22203512/individual-house-front-design-with-kids-bedroom.jpg">
        <img src="https://media.designcafe.com/wp-content/uploads/2020/07/22203512/individual-house-front-design-with-kids-bedroom.jpg" alt="Cinque Terre" width="600" height="400">
      </a>
     
    </div></center>
    <center><p>
    </tr>
                  
    
    <center>
    <center>
          <font color="red">
            SELLER DETAILS:
          </font>
        </center>
        <table border="1" style="height: 70px;">



          <tr>
          <th>S_ID </th>
          
          
          
          <th>NAME </th>
          <th>PH_NUMBER </th>
          <th>EMAIL </th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
          
          $sql = "SELECT * FROM seller1 where s_id = 's03'";
          $sql1 = "SELECT ph_number FROM seller2 where s_id = 's03'";
          $sql2 = "SELECT email FROM seller3 where s_id = 's03'";
          
          $result=mysqli_query($con,$sql);
          $result1=mysqli_query($con,$sql1);
          $num=mysqli_num_rows($result);
          $num1=mysqli_num_rows($result1);
          $result2=mysqli_query($con,$sql2);
          $num2=mysqli_num_rows($result2);
          if($num>0 )
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["s_id"]."</td><td>".$data["name"]."</td>";
          
          
          }
          while($data = $result1->fetch_assoc()){
            echo "<td>".$data["ph_number"]."</td>";
        
        
        }
        while($data = $result2->fetch_assoc()){
          echo "<td>".$data["email"]."</td>";
      
      
      }
         
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>
         </p>  
         <center><br>
          <font color="red">
          PROPERTY DETAILS:
          </font>
        </center>
        <table border="1" style="height: 70px;">



          <tr>
          <th>PROPERTY_ID </th>
                   
          
          <th>S_ID </th>
          
          <th>NAME</th>
          <th>LOCATION</th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
                 
          $sql = "SELECT Property_id,s_id,name,location FROM Property where Property_id = 'pr03'";
          $result=mysqli_query($con,$sql);
          $num=mysqli_num_rows($result);
          if($num>0)
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["Property_id"]."</td><td>".$data["s_id"]."</td><td>".$data["name"]."</td><td>".$data["location"]."</td>";
          
          }
          echo "</table>";
          }
          
          ?>
          </tr>
          </table>
          <center><br>
          <font color="red">
            ADMIN DETAILS:
          </font>
        </center>

        <table border="1" style="height: 70px;">

        <tr>
          <th>A_ID </th>
          
          
          
          <th>NAME </th>
          <th>PH_NUMBER </th>
          <th>EMAIL </th>
          
          <?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
          
          $sql = "SELECT * FROM admin1 where A_id = 'A05'";
          $sql1 = "SELECT ph_number FROM admin2 where A_id = 'A05'";
          $sql2 = "SELECT email_ID FROM admin3 where A_id = 'A05'";
          
          $result=mysqli_query($con,$sql);
          $result1=mysqli_query($con,$sql1);
          $num=mysqli_num_rows($result);
          $num1=mysqli_num_rows($result1);
          $result2=mysqli_query($con,$sql2);
          $num2=mysqli_num_rows($result2);
          if($num>0 )
          {
          while($data = $result->fetch_assoc()){
              echo "<tr><td>".$data["A_id"]."</td><td>".$data["A_name"]."</td>";
          
          
          }
          while($data = $result1->fetch_assoc()){
            echo "<td>".$data["ph_number"]."</td>";
        
        
        }
        while($data = $result2->fetch_assoc()){
          echo "<td>".$data["email_ID"]."</td>";
      
      
      }
         
          echo "</table>";
          }
          
          ?>
          </tr>
          </table><br><br>
         </p>  
         
          
          </div>

</body>
</html>


