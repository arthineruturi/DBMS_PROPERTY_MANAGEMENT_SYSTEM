
<?php
include 'connect.php';
 ?>

<!DOCTYPE html>

<html>
<title>ADMINSTRATOR</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4 {font-family:"Lato", sans-serif}
.mySlides {display:none}
.w3-tag, .fa {cursor:pointer}
.w3-tag {height:15px;width:15px;padding:0;margin-top:6px}


</style>
<body>
  <header class="w3-display-container w3-content w3-center" style="max-width:10000px">
    <img class="w3-image" src="https://t3.ftcdn.net/jpg/01/57/34/62/360_F_157346244_A6Oml9kXsQdK3WaVVg91UnzheU0YeFpe.jpg" alt="Me" width="90%" height="60">
    <div class="w3-display-middle w3-padding-large w3-border w3-wide w3-text-light-grey w3-center">
    </div>
<!-- Links (sit on top) -->
<div class="w3-top">
  <div class="w3-row w3-large w3-light-grey">
    <div class="w3-col s3">
      <a href="Main.html" class="w3-button w3-block">Home</a>  
    </div>
    <div class="w3-col s3">
      <a href="#plans" class="w3-button w3-block">Appointments</a>
    </div>
    <div class="w3-col s3">
      <a href="#about" class="w3-button w3-block">Employees</a>
    </div>
    <div class="w3-col s3">
      <a href="#contact" class="w3-button w3-block">Profile</a>
    </div>
  </div>
</div>

<!-- Content -->
<div class="w3-content" style="max-width:1100px;margin-top:80px;margin-bottom:80px">

  <div class="w3-panel">
    <h1><b>ADMINSTRATOR</b></h1> 
    
  </div>

  <!-- Grid -->
  <div class="w3-row w3-container">
    <div class="w3-center w3-padding-64">
      <span class="w3-xlarge w3-bottombar w3-border-dark-grey w3-padding-16">Achievements</span>
    </div>
    <div class="w3-col l3 m6 w3-light-grey w3-container w3-padding-16">
      <h3>Improvement</h3>
      <p>Improved the current Propmaina software, making it 50% more efficient than before.</p>
    </div>

    <div class="w3-col l3 m6 w3-grey w3-container w3-padding-16">
      <h3>Best Employee award</h3>
      <p>Led development of DotCode. Wrote 80% of the code, and reviewed the rest. </p>
    </div>

    <div class="w3-col l3 m6 w3-dark-grey w3-container w3-padding-16">
      <h3>Acharya</h3>
      <p>Trained 50+ individuals in handling bussiness development cycles, as part of their induction processes..</p>
    </div>

    <div class="w3-col l3 m6 w3-black w3-container w3-padding-16">
      <h3>25th Anniversary</h3>
      <p>Chosen as the only employee to represent the company at the Annual Software Engineers Forum..</p> 
    </div>
  </div>
  <br><br><br>
  <div class="w3-container">
    <h3 class="w3-xlarge w3-padding-16"> General Stats</h3>
    <p>New Visitors</p>
    <div class="w3-grey">
      <div class="w3-container w3-center w3-padding w3-green" style="width:75%">+75%</div>
    </div>

    <p>New Users</p>
    <div class="w3-grey">
      <div class="w3-container w3-center w3-padding w3-orange" style="width:50%">+50%</div>
    </div>

    <p>Profit (Compared to last year)</p> 
    <div class="w3-grey">
      <div class="w3-container w3-center w3-padding w3-red" style="width:35%">+35%</div>
    </div>
  </div>
  <hr>
  <!-- Grid -->
  <div class="w3-row-padding" id="plans">
    <div class="w3-center w3-padding-64">
      <h3>Appointments</h3>
      <p>The buyers and sellers are waiting for you  :)</p>
    </div>
   
    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-center w3-hover-shadow">
      
        <li class="w3-black w3-xlarge w3-padding-32">CHANDANA</li>

        <li class="w3-padding-16"><b>ID :</b> B05</li>

        <li class="w3-padding-16"><b>Ap Id: </b> ap01</li>

        <li class="w3-padding-16"><b>Appointment place:</b> bhupallapally</li>
        
        <li class="w3-padding-16"><b>Contact:</b>7865642318</li>
        <li class="w3-padding-16"><br>
          <h2 class="w3-wide">10:00</h2>
          <span class="w3-opacity">AM</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-green w3-padding-large" onclick="myFunction()">Accept</button> 
          <button class="w3-button w3-red w3-padding-large" onclick="dec()">Decline</button>
        </li>
      </ul>
    </div> 

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-center w3-hover-shadow">
        <li class="w3-dark-grey w3-xlarge w3-padding-32">RAGHAVA VARMA</li>
        <li class="w3-padding-16"><b>ID :</b> B01</li>
        <li class="w3-padding-16"><b>Ap Id: </b>ap03 </li>
        <li class="w3-padding-16"><b>Appointment place:</b> D no:- 10/5/34,Kukkatpally </li>
        
        <li class="w3-padding-16"><b>Contact:</b>9865742312</li>
        <li class="w3-padding-16"><br>
          <h2 class="w3-wide">12:00</h2>
          <span class="w3-opacity">PM</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
        <button class="w3-button w3-green w3-padding-large" onclick="myFunction()">Accept</button> 
          <button class="w3-button w3-red w3-padding-large" onclick="dec()">Decline</button>
        </li>
      </ul>
    </div>

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-center w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">SREEYA</li>
        <li class="w3-padding-16"><b>ID :</b> B03</li>
        <li class="w3-padding-16"><b>Ap Id: </b>ap04 </li>
        <li class="w3-padding-16"><b>Appointment place:</b> D no:- Propmania Office </li>
        
        <li class="w3-padding-16"><b>Contact:</b>9865742312</li>
        <li class="w3-padding-16"><br>
          <h2 class="w3-wide">1:00</h2>
          <span class="w3-opacity">PM</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
        <button class="w3-button w3-green w3-padding-large" onclick="myFunction()">Accept</button> 
          <button class="w3-button w3-red w3-padding-large" onclick="dec()">Decline</button>
        </li>
      </ul>
    </div>
    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-center w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">KAVYA</li>
        <li class="w3-padding-16"><b>ID :</b> B05</li>
        <li class="w3-padding-16"><b>Ap Id: </b>ap05 </li>
        <li class="w3-padding-16"><b>Appointment place:</b> D no:- 10/55/37,Vidyanagar </li>
        
        <li class="w3-padding-16"><b>Contact:</b>9680845787</li>
        <li class="w3-padding-16"><br>
          <h2 class="w3-wide">3:00</h2>
          <span class="w3-opacity">PM</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
        <button class="w3-button w3-green w3-padding-large" onclick="myFunction()">Accept</button> 
          <button class="w3-button w3-red w3-padding-large" onclick="dec()">Decline</button>
        </li>
      </ul>
    </div>
    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-center w3-hover-shadow">
        <li class="w3-dark-grey w3-xlarge w3-padding-32">Disha</li>
        <li class="w3-padding-16"><b>ID :</b> B07</li>
        <li class="w3-padding-16"><b>Ap Id: </b>ap06 </li>
        <li class="w3-padding-16"><b>Appointment place:</b> C'douz cafe,Near Propmania Office </li>
        
        <li class="w3-padding-16"><b>Contact:</b>7890695983</li>
        <li class="w3-padding-16"><br>
          <h2 class="w3-wide">4:00</h2>
          <span class="w3-opacity">PM</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
        <button class="w3-button w3-green w3-padding-large" onclick="myFunction()">Accept</button> 
          <button class="w3-button w3-red w3-padding-large" onclick="dec()">Decline</button>
        </li>
      </ul>
    </div>

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-center w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">JYOTHSNA</li>
        <li class="w3-padding-16"><b>ID :</b> B09</li>
        <li class="w3-padding-16"><b>Ap Id: </b>ap07 </li>
        <li class="w3-padding-16"><b>Appointment place:</b> D no:- 10-8-84,Secunderabad Cantonment </li>
        
        <li class="w3-padding-16"><b>Contact:</b>6300345789</li>
        <li class="w3-padding-16"><br>
          <h2 class="w3-wide">5:00</h2>
          <span class="w3-opacity">PM</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
        <button class="w3-button w3-green w3-padding-large" onclick="myFunction()">Accept</button> 
          <button class="w3-button w3-red w3-padding-large" onclick="dec()">Decline</button>
        </li>
      </ul>
    </div>
  </div> 

  <!-- Grid -->
  <div class="w3-row-padding" id="about">
    <div class="w3-center w3-padding-64">
      <span class="w3-xlarge w3-bottombar w3-border-dark-grey w3-padding-16">Employees</span>
    </div>

    <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4">
        <img src="https://media.istockphoto.com/photos/millenial-businessman-leaning-confidently-on-a-dark-glass-wall-with-picture-id681904114?k=20&m=681904114&s=612x612&w=0&h=YQHOGjKZKgntrZwg__EtSROLvk2xfT8wi76Fwyd001w=" alt="John" style="width:100%">
        <div class="w3-container">


          <h3> </h3>
          <h3>Sourish rao</h3>
          <p class="w3-opacity">Sr.Broker </p>
          <p><li class="w3-padding-16"><b>ID :</b> Br01</li>
            <li class="w3-padding-16"><b>Contact:</b>9300345789</li></p>
          <p><button class="w3-button w3-light-grey w3-block" onclick="req()">Assign</button></p>
        </div>
      </div>
    </div>
    
    
    <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4">
        <img src="https://media.istockphoto.com/photos/portrait-of-happy-young-man-picture-id958064228?k=20&m=958064228&s=612x612&w=0&h=y5s8sZQZcOd9sa338Wpquwc3vI2RB7_w5vHToUPA-j8=" alt="Mike" style="width:100%">
        <div class="w3-container">
          <h3>Mounish Gopal</h3>
          <p class="w3-opacity">Broker</p>
          <p><li class="w3-padding-16"><b>ID :</b> Br02</li> 
            <li class="w3-padding-16"><b>Contact:</b>8380346788</li></p>
            <p><button class="w3-button w3-light-grey w3-block" onclick="req()">Assign</button></p>
        </div>
      </div>
    </div>

    <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4">
        <img src="https://media.istockphoto.com/photos/young-indian-office-worker-looking-at-camera-picture-id1060763672?k=20&m=1060763672&s=612x612&w=0&h=-gMgdinQ9nM12gJ4g4oJ0O1Hd9O7L8xH214_t7BQ4mw=" alt="Jane" style="width:100%">
        <div class="w3-container">
          <h3>Ranveer Singh</h3>
          <p class="w3-opacity">jr.Broker</p>
          <p><li class="w3-padding-16"><b>ID :</b> Br09</li>
            <li class="w3-padding-16"><b>Contact:</b>7890848769</li></p>
            <p><button class="w3-button w3-light-grey w3-block" onclick="req()">Assign</button></p>
        </div>
      </div>
    </div>
  </div>

 <!-- Contact -->
 <div class="w3-center w3-padding-64" id="contact">
  <span class="w3-xlarge w3-bottombar w3-border-dark-grey w3-padding-16">Our Admin</span>
</div>

<form action="edit1.php" class="w3-container">
  <p>
    <i style="font-size:24px" class="fa">&#xf2c3;</i><b> Company Id:</b> a01 <br><br>
    <i style="font-size:24px" class="fa">&#xf007;</i><b> Name :</b>Siva sreenivas<br> <br>
    <i style="font-size:24px" class="fa">&#xf095;</i> <b> Contact number:</b> 9980345781 <br><br>
    <i style="font-size:24px" class="fa">&#xf0e0;</i> <b> Email Id:</b> Siva sreenivas@gmail.com<br><br>
    <i style="font-size:24px" class="fa">&#xf2ba;</i><b> Address :</b> 1, Kash Kunj, S V Rd, <br> Opposite Mamta Hotel, Malad (w),Telangana. <br><br>
  </p>
  <button type="submit" class="w3-button w3-block w3-black" >Edit</button>
</form>

</div>
<footer class="w3-padding-32 w3-black w3-center w3-margin-top">
  <h5>Find Us On</h5>
  <div class="w3-xlarge w3-padding-16">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
  </div>
  <p>Powered by <a href="#" target="_blank" class="w3-hover-text-green">propmania</a></p>
</footer>

<script>
function myFunction() 
{
  alert("Appointment is Accepted!");
}
function dec() 
{
  alert("Appointment Request is cancelled!");
}
function req() 
{
  alert("Request to the employee has been made!");
}
</script>

</body>
</html>
