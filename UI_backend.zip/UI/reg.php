<!DOCTYPE html>
<html lang="en">



<head>
<meta charset="UTF-8">



<meta http-equiv="X-UA-Compatible" content="IE=edge">



<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<table>



<tr>
<th>br_id </th>



<th>NAME </th>
<th>commission</th>
<th>ph_number </th>
<th>email_id</th>

<?php
          $host = "localhost";
          $user = "root";
          $password = '';
          $db_name = "prop";
          
          $con = mysqli_connect($host, $user, $password, $db_name);
          if(mysqli_connect_errno())
          {
          die("Failed to connect with MySQL: ". mysqli_connect_error());
          }
          
          $sql = "SELECT* FROM broker1 where br_id = 'br05'";
          $sql1 = "SELECT ph_number FROM broker2 where br_id = 'br05'";
          $sql2 = "SELECT email_id FROM broker3 where br_id = 'br05'";
          
          $result=mysqli_query($con,$sql);
          $result1=mysqli_query($con,$sql1);
          $num=mysqli_num_rows($result);
          $num1=mysqli_num_rows($result1);
          $result2=mysqli_query($con,$sql2);
          $num2=mysqli_num_rows($result2);
          if($num>0 )
          {
          while($data = $result->fetch_assoc()){
            echo "<tr><td>".$data["br_id"]."</td><td>".$data["name"]."</td><td>".$data["commission"]."</td>";
          
          
          }
          while($data = $result1->fetch_assoc()){
            echo "<td>".$data["ph_number"]."</td>";
        
        
        }
        while($data = $result2->fetch_assoc()){
          echo "<td>".$data["email_id"]."</td>";
      
      
      }
         
          echo "</table>";
          }
          
          ?>
</tr>
</table>



</body>



</html>



</body>



</html>